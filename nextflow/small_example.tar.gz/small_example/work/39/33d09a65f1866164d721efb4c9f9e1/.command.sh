#!/bin/bash -ue
mkidr tmp
