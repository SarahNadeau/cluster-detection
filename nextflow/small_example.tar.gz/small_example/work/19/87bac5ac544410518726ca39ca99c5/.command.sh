#!/bin/bash -ue
mkdir /tmp
