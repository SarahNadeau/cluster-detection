#!/bin/bash -ue
mafft -h
