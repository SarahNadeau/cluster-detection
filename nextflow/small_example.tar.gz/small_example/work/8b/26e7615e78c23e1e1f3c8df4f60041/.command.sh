#!/bin/bash -ue
mafft --auto --addfragments input.fasta reference.fasta > alignment.fasta
