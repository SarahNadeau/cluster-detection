#!/bin/bash
set -euo pipefail

export TMPDIR=`pwd`/tmp

ml purge
ml nextflow/23.04.0
ml Apptainer/1.1.6

nextflow run example.nf -c nf.config.noslurm -profile apptainer

